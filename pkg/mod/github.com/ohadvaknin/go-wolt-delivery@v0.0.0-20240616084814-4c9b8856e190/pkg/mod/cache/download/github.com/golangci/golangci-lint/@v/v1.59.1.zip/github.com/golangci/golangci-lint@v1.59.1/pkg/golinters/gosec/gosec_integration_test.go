package gosec

import (
	"testing"

	"github.com/golangci/golangci-lint/test/testshared/integration"
)

func TestFromTestdata(t *testing.T) {
	integration.RunTestdata(t)
}
