//golangcitest:args -Emaintidx
package testdata

func over20() {
}

func under20() { // want "Function name: under20, Cyclomatic Complexity: 76, Halstead Volume: 1636.00, Maintainability Index: 17"
	for true {
		if false {
			if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			}
		} else if false {
			if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			}
		} else if false {
			if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			}
		} else if false {
			if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			}
		} else {
			if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			}
		}
	}
}
