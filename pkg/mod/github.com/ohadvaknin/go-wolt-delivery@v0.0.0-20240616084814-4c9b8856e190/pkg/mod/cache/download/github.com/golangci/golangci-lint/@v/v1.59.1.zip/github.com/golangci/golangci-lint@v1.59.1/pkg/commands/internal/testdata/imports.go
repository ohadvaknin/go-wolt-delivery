package main

import (
	_ "example.com/foo/bar/test"
	_ "example.org/foo/bar/test"
)
