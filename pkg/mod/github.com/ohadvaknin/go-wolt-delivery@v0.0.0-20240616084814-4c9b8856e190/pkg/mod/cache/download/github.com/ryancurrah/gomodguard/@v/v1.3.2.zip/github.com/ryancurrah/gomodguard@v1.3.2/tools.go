//go:build tools

package gomodguard

import _ "github.com/t-yuki/gocover-cobertura"
