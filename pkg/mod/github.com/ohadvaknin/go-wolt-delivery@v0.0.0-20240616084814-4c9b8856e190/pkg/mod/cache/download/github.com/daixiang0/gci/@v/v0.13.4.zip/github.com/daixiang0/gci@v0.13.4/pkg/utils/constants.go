package utils

const (
	Indent       = '\t'
	Linebreak    = '\n'
	WinLinebreak = '\r'

	Colon = ":"

	LeftParenthesis  = '('
	RightParenthesis = ')'
)
